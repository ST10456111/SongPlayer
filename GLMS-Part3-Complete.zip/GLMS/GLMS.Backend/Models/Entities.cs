using System.ComponentModel.DataAnnotations;

namespace GLMS.Backend.Models
{
    // ── Enums ────────────────────────────────────────────────────────────────
    public enum ContractStatus  { Draft, Active, Expired, OnHold }
    public enum ServiceLevel    { Standard, Premium, Enterprise }
    public enum RequestStatus   { Pending, InProgress, Completed, Cancelled }

    // ── Domain Entities ──────────────────────────────────────────────────────

    /// <summary>A client / customer of the logistics company.</summary>
    public class Client
    {
        public int Id { get; set; }

        [Required, MaxLength(150)]
        public string Name { get; set; } = string.Empty;

        [Required, MaxLength(200)]
        public string ContactDetails { get; set; } = string.Empty;

        [Required, MaxLength(100)]
        public string Region { get; set; } = string.Empty;

        public ICollection<Contract> Contracts { get; set; } = new List<Contract>();
    }

    /// <summary>A service agreement between the company and a client.</summary>
    public class Contract
    {
        public int Id { get; set; }

        [Required]
        public int ClientId { get; set; }
        public Client? Client { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }

        public ContractStatus Status       { get; set; } = ContractStatus.Draft;
        public ServiceLevel   ServiceLevel { get; set; } = ServiceLevel.Standard;

        /// <summary>Relative path to the uploaded signed-agreement PDF.</summary>
        public string? SignedAgreementPath { get; set; }

        public ICollection<ServiceRequest> ServiceRequests { get; set; } = new List<ServiceRequest>();
    }

    /// <summary>An individual job / service request logged under a contract.</summary>
    public class ServiceRequest
    {
        public int Id { get; set; }

        [Required]
        public int ContractId { get; set; }
        public Contract? Contract { get; set; }

        [Required, MaxLength(500)]
        public string Description { get; set; } = string.Empty;

        [Range(0, double.MaxValue)]
        public decimal CostUsd          { get; set; }
        public decimal CostZar          { get; set; }
        public decimal ExchangeRateUsed { get; set; }

        public RequestStatus Status    { get; set; } = RequestStatus.Pending;
        public DateTime      CreatedAt { get; set; } = DateTime.UtcNow;
    }

    // ── API Request DTOs ─────────────────────────────────────────────────────

    public class ClientUpsertDto
    {
        [Required, MaxLength(150)]  public string Name           { get; set; } = string.Empty;
        [Required, MaxLength(200)]  public string ContactDetails { get; set; } = string.Empty;
        [Required, MaxLength(100)]  public string Region         { get; set; } = string.Empty;
    }

    public class ContractCreateDto
    {
        [Required]  public int           ClientId     { get; set; }
        [Required]  public DateTime      StartDate    { get; set; } = DateTime.Today;
        [Required]  public DateTime      EndDate      { get; set; } = DateTime.Today.AddYears(1);
        public ContractStatus  Status       { get; set; } = ContractStatus.Draft;
        public ServiceLevel    ServiceLevel { get; set; } = ServiceLevel.Standard;
    }

    public class ContractStatusPatchDto
    {
        [Required]  public ContractStatus Status { get; set; }
    }

    public class ServiceRequestCreateDto
    {
        [Required]                              public int     ContractId  { get; set; }
        [Required, MaxLength(500)]              public string  Description { get; set; } = string.Empty;
        [Required, Range(0.01, double.MaxValue)] public decimal CostUsd    { get; set; }
    }

    public class LoginDto
    {
        [Required, EmailAddress]  public string Email    { get; set; } = string.Empty;
        [Required]                public string Password { get; set; } = string.Empty;
    }

    public class AuthResponseDto
    {
        public string   Token  { get; set; } = string.Empty;
        public string   Email  { get; set; } = string.Empty;
        public DateTime Expiry { get; set; }
    }
}
