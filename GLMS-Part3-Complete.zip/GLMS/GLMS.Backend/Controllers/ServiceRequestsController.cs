using GLMS.Backend.Models;
using GLMS.Backend.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Backend.Controllers
{
    /// <summary>
    /// Service request management. Uses Decorator + Strategy patterns via IServiceRequestService.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    [Produces("application/json")]
    public class ServiceRequestsController : ControllerBase
    {
        private readonly IServiceRequestService _srService;

        public ServiceRequestsController(IServiceRequestService srService)
            => _srService = srService;

        /// <summary>Returns all service requests ordered by creation date.</summary>
        [HttpGet]
        [AllowAnonymous]
        [ProducesResponseType(typeof(IEnumerable<ServiceRequest>), 200)]
        public async Task<ActionResult<IEnumerable<ServiceRequest>>> GetAll()
            => Ok(await _srService.GetAllAsync());

        /// <summary>Returns all active contracts (for the create-request dropdown).</summary>
        [HttpGet("active-contracts")]
        [ProducesResponseType(typeof(IEnumerable<Contract>), 200)]
        public async Task<ActionResult<IEnumerable<Contract>>> GetActiveContracts()
            => Ok(await _srService.GetActiveContractsAsync());

        /// <summary>Returns a single service request by ID.</summary>
        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(ServiceRequest), 200)]
        [ProducesResponseType(404)]
        public async Task<ActionResult<ServiceRequest>> GetById(int id)
        {
            var request = await _srService.GetByIdAsync(id);
            return request == null ? NotFound() : Ok(request);
        }

        /// <summary>
        /// Creates a service request. Applies Decorator pipeline (validation, USD→ZAR conversion,
        /// audit log) then Strategy pricing based on the contract's service level.
        /// </summary>
        [HttpPost]
        [ProducesResponseType(typeof(ServiceRequest), 201)]
        [ProducesResponseType(400)]
        public async Task<ActionResult<ServiceRequest>> Create([FromBody] ServiceRequestCreateDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var (request, error) = await _srService.CreateAsync(dto);
            if (error != null) return BadRequest(new { error });

            return CreatedAtAction(nameof(GetById), new { id = request!.Id }, request);
        }

        /// <summary>Deletes a service request by ID.</summary>
        [HttpDelete("{id:int}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _srService.DeleteAsync(id);
            return deleted ? NoContent() : NotFound();
        }
    }
}
