using GLMS.Backend.Models;
using GLMS.Backend.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Backend.Controllers
{
    /// <summary>
    /// Contract lifecycle management: list, filter, create, update status, delete.
    /// All business logic lives in IContractService — this controller is routing only.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    [Produces("application/json")]
    public class ContractsController : ControllerBase
    {
        private readonly IContractService _contractService;

        public ContractsController(IContractService contractService)
            => _contractService = contractService;

        /// <summary>Returns all contracts. Supports optional query-string filtering.</summary>
        [HttpGet]
        [AllowAnonymous]
        [ProducesResponseType(typeof(IEnumerable<Contract>), 200)]
        public async Task<ActionResult<IEnumerable<Contract>>> GetAll(
            [FromQuery] DateTime?       from,
            [FromQuery] DateTime?       to,
            [FromQuery] ContractStatus? status)
        {
            var contracts = (from == null && to == null && status == null)
                ? await _contractService.GetAllAsync()
                : await _contractService.SearchAsync(from, to, status);

            return Ok(contracts);
        }

        /// <summary>Returns a single contract including its service requests.</summary>
        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(Contract), 200)]
        [ProducesResponseType(404)]
        public async Task<ActionResult<Contract>> GetById(int id)
        {
            var contract = await _contractService.GetByIdAsync(id);
            return contract == null ? NotFound() : Ok(contract);
        }

        /// <summary>Creates a new contract.</summary>
        [HttpPost]
        [ProducesResponseType(typeof(Contract), 201)]
        [ProducesResponseType(400)]
        public async Task<ActionResult<Contract>> Create([FromBody] ContractCreateDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var (contract, error) = await _contractService.CreateAsync(dto);
            if (error != null) return BadRequest(new { error });

            return CreatedAtAction(nameof(GetById), new { id = contract.Id }, contract);
        }

        /// <summary>Updates all fields of an existing contract.</summary>
        [HttpPut("{id:int}")]
        [ProducesResponseType(typeof(Contract), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<ActionResult<Contract>> Update(int id, [FromBody] ContractCreateDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var (contract, error) = await _contractService.UpdateAsync(id, dto);
            if (error != null) return NotFound(new { error });

            return Ok(contract);
        }

        /// <summary>Approves, declines, or changes the status of a contract.</summary>
        [HttpPatch("{id:int}/status")]
        [ProducesResponseType(typeof(Contract), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<ActionResult<Contract>> PatchStatus(
            int id, [FromBody] ContractStatusPatchDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var (contract, error) = await _contractService.UpdateStatusAsync(id, dto.Status);
            if (error != null) return NotFound(new { error });

            return Ok(contract);
        }

        /// <summary>Deletes a contract by ID.</summary>
        [HttpDelete("{id:int}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _contractService.DeleteAsync(id);
            return deleted ? NoContent() : NotFound();
        }
    }
}
