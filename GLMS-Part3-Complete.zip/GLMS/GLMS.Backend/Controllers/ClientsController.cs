using GLMS.Backend.Models;
using GLMS.Backend.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Backend.Controllers
{
    /// <summary>
    /// Client CRUD operations. All data access delegated to IClientService.
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    [Produces("application/json")]
    public class ClientsController : ControllerBase
    {
        private readonly IClientService _clientService;

        public ClientsController(IClientService clientService)
            => _clientService = clientService;

        /// <summary>Returns all clients with their contracts.</summary>
        [HttpGet]
        [AllowAnonymous]
        [ProducesResponseType(typeof(IEnumerable<Client>), 200)]
        public async Task<ActionResult<IEnumerable<Client>>> GetAll()
            => Ok(await _clientService.GetAllAsync());

        /// <summary>Returns a single client by ID.</summary>
        [HttpGet("{id:int}")]
        [ProducesResponseType(typeof(Client), 200)]
        [ProducesResponseType(404)]
        public async Task<ActionResult<Client>> GetById(int id)
        {
            var client = await _clientService.GetByIdAsync(id);
            return client == null ? NotFound() : Ok(client);
        }

        /// <summary>Creates a new client.</summary>
        [HttpPost]
        [ProducesResponseType(typeof(Client), 201)]
        [ProducesResponseType(400)]
        public async Task<ActionResult<Client>> Create([FromBody] ClientUpsertDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var client = await _clientService.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = client.Id }, client);
        }

        /// <summary>Updates an existing client.</summary>
        [HttpPut("{id:int}")]
        [ProducesResponseType(typeof(Client), 200)]
        [ProducesResponseType(400)]
        [ProducesResponseType(404)]
        public async Task<ActionResult<Client>> Update(int id, [FromBody] ClientUpsertDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var result = await _clientService.UpdateAsync(id, dto);
            return result == null ? NotFound() : Ok(result);
        }

        /// <summary>Deletes a client by ID.</summary>
        [HttpDelete("{id:int}")]
        [ProducesResponseType(204)]
        [ProducesResponseType(404)]
        public async Task<IActionResult> Delete(int id)
        {
            var deleted = await _clientService.DeleteAsync(id);
            return deleted ? NoContent() : NotFound();
        }
    }
}
