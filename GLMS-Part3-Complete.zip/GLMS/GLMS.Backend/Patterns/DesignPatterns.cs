using GLMS.Backend.Models;

namespace GLMS.Backend.Patterns
{
    // ════════════════════════════════════════════════════════════════════════
    // OBSERVER PATTERN — Contract status notifications
    // ════════════════════════════════════════════════════════════════════════

    public interface IContractObserver
    {
        void Update(int contractId, string oldStatus, string newStatus);
    }

    public class ContractSubject
    {
        private readonly List<IContractObserver> _observers = new();

        public void Attach(IContractObserver o) => _observers.Add(o);
        public void Detach(IContractObserver o) => _observers.Remove(o);

        public void Notify(int contractId, string oldStatus, string newStatus)
        {
            foreach (var o in _observers)
                o.Update(contractId, oldStatus, newStatus);
        }
    }

    public class AuditLogObserver : IContractObserver
    {
        public readonly List<string> LogEntries = new();

        public void Update(int contractId, string oldStatus, string newStatus)
        {
            var entry = $"[AUDIT] Contract #{contractId}: {oldStatus} → {newStatus} at {DateTime.UtcNow:O}";
            LogEntries.Add(entry);
            Console.WriteLine(entry);
        }
    }

    public class EmailAlertObserver : IContractObserver
    {
        public readonly List<string> SentAlerts = new();

        public void Update(int contractId, string oldStatus, string newStatus)
        {
            if (newStatus is "Expired" or "OnHold")
            {
                var msg = $"[EMAIL] ALERT: Contract #{contractId} changed to {newStatus} (was: {oldStatus})";
                SentAlerts.Add(msg);
                Console.WriteLine(msg);
            }
        }
    }

    public class DashboardObserver : IContractObserver
    {
        public readonly List<string> Notifications = new();

        public void Update(int contractId, string oldStatus, string newStatus)
        {
            var note = $"[DASHBOARD] Contract #{contractId}: {oldStatus} → {newStatus}";
            Notifications.Add(note);
            Console.WriteLine(note);
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // STRATEGY PATTERN — Service-level pricing
    // ════════════════════════════════════════════════════════════════════════

    public interface IPricingStrategy
    {
        decimal CalculatePrice(decimal baseAmountZar);
        string StrategyName { get; }
    }

    public class StandardPricingStrategy : IPricingStrategy
    {
        public string StrategyName => "Standard";
        public decimal CalculatePrice(decimal baseAmountZar) => baseAmountZar;
    }

    public class PremiumPricingStrategy : IPricingStrategy
    {
        public string StrategyName => "Premium";
        public decimal CalculatePrice(decimal baseAmountZar) => baseAmountZar * 1.15m;
    }

    public class EnterprisePricingStrategy : IPricingStrategy
    {
        public string StrategyName => "Enterprise";
        public decimal CalculatePrice(decimal baseAmountZar) => (baseAmountZar * 1.25m) + 500m;
    }

    public class PricingContext
    {
        private IPricingStrategy _strategy;

        public PricingContext(IPricingStrategy strategy) => _strategy = strategy;

        public void SetStrategy(IPricingStrategy strategy) => _strategy = strategy;
        public decimal ExecutePricing(decimal baseAmountZar) => _strategy.CalculatePrice(baseAmountZar);
        public string CurrentStrategyName => _strategy.StrategyName;
    }

    public static class PricingStrategyFactory
    {
        public static IPricingStrategy GetStrategy(string serviceLevel) =>
            serviceLevel switch
            {
                "Premium"    => new PremiumPricingStrategy(),
                "Enterprise" => new EnterprisePricingStrategy(),
                _            => new StandardPricingStrategy()
            };
    }

    // ════════════════════════════════════════════════════════════════════════
    // DECORATOR PATTERN — Service request processing pipeline
    // ════════════════════════════════════════════════════════════════════════

    public interface IServiceRequestProcessor
    {
        string? Process(ServiceRequest request);
    }

    public class BaseRequestProcessor : IServiceRequestProcessor
    {
        public string? Process(ServiceRequest request) => null;
    }

    public abstract class ServiceRequestDecorator : IServiceRequestProcessor
    {
        protected readonly IServiceRequestProcessor _inner;
        protected ServiceRequestDecorator(IServiceRequestProcessor inner) => _inner = inner;
        public virtual string? Process(ServiceRequest request) => _inner.Process(request);
    }

    public class ValidationDecorator : ServiceRequestDecorator
    {
        private readonly ContractStatus _contractStatus;

        public ValidationDecorator(IServiceRequestProcessor inner, ContractStatus status)
            : base(inner) => _contractStatus = status;

        public override string? Process(ServiceRequest request)
        {
            if (_contractStatus == ContractStatus.Expired)
                return "Cannot create a service request: the linked contract is Expired.";
            if (_contractStatus == ContractStatus.OnHold)
                return "Cannot create a service request: the linked contract is On Hold.";
            return base.Process(request);
        }
    }

    public class CurrencyDecorator : ServiceRequestDecorator
    {
        private readonly decimal _usdToZarRate;

        public CurrencyDecorator(IServiceRequestProcessor inner, decimal usdToZarRate)
            : base(inner) => _usdToZarRate = usdToZarRate;

        public override string? Process(ServiceRequest request)
        {
            if (_usdToZarRate <= 0)
                return "Invalid exchange rate: cannot perform currency conversion.";

            request.CostZar          = Math.Round(request.CostUsd * _usdToZarRate, 2, MidpointRounding.AwayFromZero);
            request.ExchangeRateUsed = _usdToZarRate;

            return base.Process(request);
        }
    }

    public class AuditLoggingDecorator : ServiceRequestDecorator
    {
        public AuditLoggingDecorator(IServiceRequestProcessor inner) : base(inner) { }

        public override string? Process(ServiceRequest request)
        {
            var result = base.Process(request);
            if (result == null)
                Console.WriteLine($"[AUDIT] SR created — Contract: {request.ContractId}, " +
                                  $"USD: {request.CostUsd:F2}, ZAR: {request.CostZar:F2} " +
                                  $"(rate: {request.ExchangeRateUsed:F4}) at {DateTime.UtcNow:O}");
            return result;
        }
    }
}
