using System.Text.Json;
using GLMS.Backend.Data;
using GLMS.Backend.Models;
using GLMS.Backend.Patterns;
using Microsoft.EntityFrameworkCore;

namespace GLMS.Backend.Services
{
    // ════════════════════════════════════════════════════════════════════════
    // CURRENCY SERVICE
    // ════════════════════════════════════════════════════════════════════════

    public interface ICurrencyService
    {
        Task<decimal> GetUsdToZarRateAsync();
        decimal ConvertUsdToZar(decimal usdAmount, decimal rate);
    }

    public class CurrencyService : ICurrencyService
    {
        private readonly HttpClient             _httpClient;
        private readonly IConfiguration         _config;
        private readonly ILogger<CurrencyService> _logger;

        private decimal  _cachedRate  = 0;
        private DateTime _cacheExpiry = DateTime.MinValue;
        private readonly TimeSpan _cacheDuration = TimeSpan.FromHours(6);

        public CurrencyService(HttpClient httpClient, IConfiguration config,
                               ILogger<CurrencyService> logger)
        {
            _httpClient = httpClient;
            _config     = config;
            _logger     = logger;
        }

        public async Task<decimal> GetUsdToZarRateAsync()
        {
            if (_cachedRate > 0 && DateTime.UtcNow < _cacheExpiry)
                return _cachedRate;

            try
            {
                var url      = _config["CurrencyApi:BaseUrl"] ?? "https://open.er-api.com/v6/latest/USD";
                var response = await _httpClient.GetAsync(url);
                response.EnsureSuccessStatusCode();

                var json    = await response.Content.ReadAsStringAsync();
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var data    = JsonSerializer.Deserialize<ExchangeRateResponse>(json, options);

                if (data?.Rates != null && data.Rates.TryGetValue("ZAR", out var zarRate))
                {
                    _cachedRate  = zarRate;
                    _cacheExpiry = DateTime.UtcNow.Add(_cacheDuration);
                    return zarRate;
                }
                throw new InvalidOperationException("ZAR rate not found in API response.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Currency API failed. Using fallback.");
                return _cachedRate > 0 ? _cachedRate : 18.50m;
            }
        }

        public decimal ConvertUsdToZar(decimal usdAmount, decimal rate)
        {
            if (rate <= 0) throw new ArgumentOutOfRangeException(nameof(rate), "Rate must be positive.");
            return Math.Round(usdAmount * rate, 2, MidpointRounding.AwayFromZero);
        }

        private class ExchangeRateResponse
        {
            public string Result { get; set; } = string.Empty;
            public Dictionary<string, decimal> Rates { get; set; } = new();
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // CLIENT SERVICE
    // ════════════════════════════════════════════════════════════════════════

    public interface IClientService
    {
        Task<List<Client>> GetAllAsync();
        Task<Client?>      GetByIdAsync(int id);
        Task<Client>       CreateAsync(ClientUpsertDto dto);
        Task<Client?>      UpdateAsync(int id, ClientUpsertDto dto);
        Task<bool>         DeleteAsync(int id);
    }

    public class ClientService : IClientService
    {
        private readonly GlmsDbContext _db;
        public ClientService(GlmsDbContext db) => _db = db;

        public async Task<List<Client>> GetAllAsync() =>
            await _db.Clients
                     .Include(c => c.Contracts)
                     .OrderBy(c => c.Name)
                     .ToListAsync();

        public async Task<Client?> GetByIdAsync(int id) =>
            await _db.Clients
                     .Include(c => c.Contracts)
                         .ThenInclude(ct => ct.ServiceRequests)
                     .FirstOrDefaultAsync(c => c.Id == id);

        public async Task<Client> CreateAsync(ClientUpsertDto dto)
        {
            var client = new Client
            {
                Name           = dto.Name,
                ContactDetails = dto.ContactDetails,
                Region         = dto.Region
            };
            _db.Clients.Add(client);
            await _db.SaveChangesAsync();
            return client;
        }

        public async Task<Client?> UpdateAsync(int id, ClientUpsertDto dto)
        {
            var existing = await _db.Clients.FindAsync(id);
            if (existing == null) return null;

            existing.Name           = dto.Name;
            existing.ContactDetails = dto.ContactDetails;
            existing.Region         = dto.Region;

            await _db.SaveChangesAsync();
            return existing;
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var client = await _db.Clients.FindAsync(id);
            if (client == null) return false;
            _db.Clients.Remove(client);
            await _db.SaveChangesAsync();
            return true;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // CONTRACT SERVICE
    // ════════════════════════════════════════════════════════════════════════

    public interface IContractService
    {
        Task<List<Contract>>  GetAllAsync();
        Task<Contract?>       GetByIdAsync(int id);
        Task<List<Contract>>  SearchAsync(DateTime? from, DateTime? to, ContractStatus? status);
        Task<(Contract contract, string? error)>  CreateAsync(ContractCreateDto dto);
        Task<(Contract? contract, string? error)> UpdateStatusAsync(int id, ContractStatus newStatus);
        Task<(Contract? contract, string? error)> UpdateAsync(int id, ContractCreateDto dto);
        Task<bool>            DeleteAsync(int id);
    }

    public class ContractService : IContractService
    {
        private readonly GlmsDbContext   _db;
        private readonly ContractSubject _subject;

        public ContractService(GlmsDbContext db)
        {
            _db      = db;
            _subject = BuildSubject();
        }

        private static ContractSubject BuildSubject()
        {
            var s = new ContractSubject();
            s.Attach(new AuditLogObserver());
            s.Attach(new EmailAlertObserver());
            s.Attach(new DashboardObserver());
            return s;
        }

        public async Task<List<Contract>> GetAllAsync() =>
            await _db.Contracts
                     .Include(c => c.Client)
                     .OrderByDescending(c => c.StartDate)
                     .ToListAsync();

        public async Task<Contract?> GetByIdAsync(int id) =>
            await _db.Contracts
                     .Include(c => c.Client)
                     .Include(c => c.ServiceRequests)
                     .FirstOrDefaultAsync(c => c.Id == id);

        public async Task<List<Contract>> SearchAsync(
            DateTime? from, DateTime? to, ContractStatus? status)
        {
            var query = _db.Contracts.Include(c => c.Client).AsQueryable();
            if (from.HasValue)   query = query.Where(c => c.StartDate >= from.Value);
            if (to.HasValue)     query = query.Where(c => c.StartDate <= to.Value);
            if (status.HasValue) query = query.Where(c => c.Status == status.Value);
            return await query.OrderByDescending(c => c.StartDate).ToListAsync();
        }

        public async Task<(Contract contract, string? error)> CreateAsync(ContractCreateDto dto)
        {
            var clientExists = await _db.Clients.AnyAsync(c => c.Id == dto.ClientId);
            if (!clientExists)
                return (null!, $"Client {dto.ClientId} not found.");

            var contract = new Contract
            {
                ClientId     = dto.ClientId,
                StartDate    = dto.StartDate,
                EndDate      = dto.EndDate,
                Status       = dto.Status,
                ServiceLevel = dto.ServiceLevel
            };

            _db.Contracts.Add(contract);
            await _db.SaveChangesAsync();
            _subject.Notify(contract.Id, "None", contract.Status.ToString());
            return (contract, null);
        }

        public async Task<(Contract? contract, string? error)> UpdateStatusAsync(
            int id, ContractStatus newStatus)
        {
            var contract = await _db.Contracts.FindAsync(id);
            if (contract == null) return (null, "Contract not found.");

            var old = contract.Status.ToString();
            contract.Status = newStatus;
            await _db.SaveChangesAsync();
            _subject.Notify(id, old, newStatus.ToString());
            return (contract, null);
        }

        public async Task<(Contract? contract, string? error)> UpdateAsync(
            int id, ContractCreateDto dto)
        {
            var contract = await _db.Contracts.FindAsync(id);
            if (contract == null) return (null, "Contract not found.");

            var old = contract.Status.ToString();
            contract.ClientId     = dto.ClientId;
            contract.StartDate    = dto.StartDate;
            contract.EndDate      = dto.EndDate;
            contract.ServiceLevel = dto.ServiceLevel;

            if (contract.Status != dto.Status)
                _subject.Notify(id, old, dto.Status.ToString());

            contract.Status = dto.Status;
            await _db.SaveChangesAsync();
            return (contract, null);
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var contract = await _db.Contracts.FindAsync(id);
            if (contract == null) return false;
            _db.Contracts.Remove(contract);
            await _db.SaveChangesAsync();
            return true;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // SERVICE REQUEST SERVICE
    // ════════════════════════════════════════════════════════════════════════

    public interface IServiceRequestService
    {
        Task<List<ServiceRequest>>  GetAllAsync();
        Task<ServiceRequest?>       GetByIdAsync(int id);
        Task<List<Contract>>        GetActiveContractsAsync();
        Task<(ServiceRequest? request, string? error)> CreateAsync(ServiceRequestCreateDto dto);
        Task<bool>                  DeleteAsync(int id);
    }

    public class ServiceRequestService : IServiceRequestService
    {
        private readonly GlmsDbContext    _db;
        private readonly ICurrencyService _currencyService;

        public ServiceRequestService(GlmsDbContext db, ICurrencyService currencyService)
        {
            _db              = db;
            _currencyService = currencyService;
        }

        public async Task<List<ServiceRequest>> GetAllAsync() =>
            await _db.ServiceRequests
                     .Include(r => r.Contract)
                         .ThenInclude(c => c!.Client)
                     .OrderByDescending(r => r.CreatedAt)
                     .ToListAsync();

        public async Task<ServiceRequest?> GetByIdAsync(int id) =>
            await _db.ServiceRequests
                     .Include(r => r.Contract)
                         .ThenInclude(c => c!.Client)
                     .FirstOrDefaultAsync(r => r.Id == id);

        public async Task<List<Contract>> GetActiveContractsAsync() =>
            await _db.Contracts
                     .Include(c => c.Client)
                     .Where(c => c.Status == ContractStatus.Active)
                     .ToListAsync();

        public async Task<(ServiceRequest? request, string? error)> CreateAsync(
            ServiceRequestCreateDto dto)
        {
            var contract = await _db.Contracts.FindAsync(dto.ContractId);
            if (contract == null) return (null, "Contract not found.");

            var rate = await _currencyService.GetUsdToZarRateAsync();

            var request = new ServiceRequest
            {
                ContractId  = dto.ContractId,
                Description = dto.Description,
                CostUsd     = dto.CostUsd,
                Status      = RequestStatus.Pending,
                CreatedAt   = DateTime.UtcNow
            };

            // Decorator pipeline: Validation → Currency conversion → Audit log
            IServiceRequestProcessor processor = new BaseRequestProcessor();
            processor = new AuditLoggingDecorator(processor);
            processor = new CurrencyDecorator(processor, rate);
            processor = new ValidationDecorator(processor, contract.Status);

            var error = processor.Process(request);
            if (error != null) return (null, error);

            // Strategy: price adjustment based on service level
            var strategy = PricingStrategyFactory.GetStrategy(contract.ServiceLevel.ToString());
            request.CostZar = new PricingContext(strategy).ExecutePricing(request.CostZar);

            _db.ServiceRequests.Add(request);
            await _db.SaveChangesAsync();
            return (request, null);
        }

        public async Task<bool> DeleteAsync(int id)
        {
            var request = await _db.ServiceRequests.FindAsync(id);
            if (request == null) return false;
            _db.ServiceRequests.Remove(request);
            await _db.SaveChangesAsync();
            return true;
        }
    }
}
