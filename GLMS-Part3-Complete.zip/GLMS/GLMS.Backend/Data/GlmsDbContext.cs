using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using GLMS.Backend.Models;

namespace GLMS.Backend.Data
{
    public class GlmsDbContext : IdentityDbContext<IdentityUser>
    {
        public GlmsDbContext(DbContextOptions<GlmsDbContext> options) : base(options) { }

        public DbSet<Client>         Clients         { get; set; }
        public DbSet<Contract>       Contracts       { get; set; }
        public DbSet<ServiceRequest> ServiceRequests { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Client>(e =>
            {
                e.HasKey(c => c.Id);
                e.Property(c => c.Name).IsRequired().HasMaxLength(150);
                e.Property(c => c.ContactDetails).IsRequired().HasMaxLength(200);
                e.Property(c => c.Region).IsRequired().HasMaxLength(100);
            });

            modelBuilder.Entity<Contract>(e =>
            {
                e.HasKey(c => c.Id);
                e.Property(c => c.Status).HasConversion<string>().HasMaxLength(20);
                e.Property(c => c.ServiceLevel).HasConversion<string>().HasMaxLength(20);
                e.Property(c => c.SignedAgreementPath).HasMaxLength(500);

                e.HasOne(c => c.Client)
                 .WithMany(cl => cl.Contracts)
                 .HasForeignKey(c => c.ClientId)
                 .OnDelete(DeleteBehavior.Restrict);
            });

            modelBuilder.Entity<ServiceRequest>(e =>
            {
                e.HasKey(r => r.Id);
                e.Property(r => r.Description).IsRequired().HasMaxLength(500);
                e.Property(r => r.CostUsd).HasColumnType("decimal(18,2)");
                e.Property(r => r.CostZar).HasColumnType("decimal(18,2)");
                e.Property(r => r.ExchangeRateUsed).HasColumnType("decimal(18,4)");
                e.Property(r => r.Status).HasConversion<string>().HasMaxLength(20);

                e.HasOne(r => r.Contract)
                 .WithMany(c => c.ServiceRequests)
                 .HasForeignKey(r => r.ContractId)
                 .OnDelete(DeleteBehavior.Cascade);
            });

            // Seed clients
            modelBuilder.Entity<Client>().HasData(
                new Client { Id = 1, Name = "Acme Freight Ltd",   ContactDetails = "acme@freight.com",      Region = "ZA-Western Cape" },
                new Client { Id = 2, Name = "Global Cargo Inc",   ContactDetails = "info@globalcargo.com",  Region = "US-New York"     },
                new Client { Id = 3, Name = "EuroShip Partners",  ContactDetails = "eu@euroship.com",       Region = "EU-Germany"      }
            );

            // Seed contracts
            modelBuilder.Entity<Contract>().HasData(
                new Contract { Id = 1, ClientId = 1, StartDate = new DateTime(2025,1,1),  EndDate = new DateTime(2025,12,31), Status = ContractStatus.Active,  ServiceLevel = ServiceLevel.Standard   },
                new Contract { Id = 2, ClientId = 2, StartDate = new DateTime(2024,1,1),  EndDate = new DateTime(2024,12,31), Status = ContractStatus.Expired, ServiceLevel = ServiceLevel.Premium    },
                new Contract { Id = 3, ClientId = 3, StartDate = new DateTime(2026,1,1),  EndDate = new DateTime(2027,12,31), Status = ContractStatus.Draft,   ServiceLevel = ServiceLevel.Enterprise }
            );
        }
    }
}
