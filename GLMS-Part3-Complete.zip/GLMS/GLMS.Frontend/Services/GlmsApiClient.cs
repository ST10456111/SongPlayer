using System.Net.Http.Headers;
using System.Net.Http.Json;
using GLMS.Frontend.Models;

namespace GLMS.Frontend.Services
{
    /// <summary>
    /// Typed HTTP client that wraps every call to the GLMS Backend API.
    /// MVC controllers call this; they never touch a database directly.
    /// </summary>
    public interface IGlmsApiClient
    {
        // Auth
        Task<AuthResponseDto?> LoginAsync(string email, string password);

        // Clients
        Task<List<Client>> GetClientsAsync();
        Task<Client?>      GetClientAsync(int id);
        Task<Client?>      CreateClientAsync(string name, string contact, string region);
        Task<Client?>      UpdateClientAsync(int id, string name, string contact, string region);
        Task<bool>         DeleteClientAsync(int id);

        // Contracts
        Task<List<Contract>> GetContractsAsync(DateTime? from = null, DateTime? to = null, ContractStatus? status = null);
        Task<Contract?>      GetContractAsync(int id);
        Task<(Contract? contract, string? error)> CreateContractAsync(ContractCreateViewModel vm);
        Task<Contract?>      PatchContractStatusAsync(int id, ContractStatus newStatus);
        Task<bool>           DeleteContractAsync(int id);

        // Service Requests
        Task<List<ServiceRequest>> GetServiceRequestsAsync();
        Task<List<Contract>>       GetActiveContractsAsync();
        Task<ServiceRequest?>      GetServiceRequestAsync(int id);
        Task<(ServiceRequest? request, string? error)> CreateServiceRequestAsync(ServiceRequestCreateViewModel vm);
        Task<bool>                 DeleteServiceRequestAsync(int id);
    }

    public class GlmsApiClient : IGlmsApiClient
    {
        private readonly HttpClient          _http;
        private readonly IHttpContextAccessor _ctx;

        public GlmsApiClient(HttpClient http, IHttpContextAccessor ctx)
        {
            _http = http;
            _ctx  = ctx;
        }

        // ── Auth header helper ───────────────────────────────────────────────
        private void AttachToken()
        {
            var token = _ctx.HttpContext?.Session.GetString("JwtToken");
            _http.DefaultRequestHeaders.Authorization = string.IsNullOrEmpty(token)
                ? null
                : new AuthenticationHeaderValue("Bearer", token);
        }

        // ── Auth ─────────────────────────────────────────────────────────────
        public async Task<AuthResponseDto?> LoginAsync(string email, string password)
        {
            var r = await _http.PostAsJsonAsync("api/auth/login", new { email, password });
            return r.IsSuccessStatusCode
                ? await r.Content.ReadFromJsonAsync<AuthResponseDto>()
                : null;
        }

        // ── Clients ──────────────────────────────────────────────────────────
        public async Task<List<Client>> GetClientsAsync()
        {
            AttachToken();
            return await _http.GetFromJsonAsync<List<Client>>("api/clients") ?? new();
        }

        public async Task<Client?> GetClientAsync(int id)
        {
            AttachToken();
            try { return await _http.GetFromJsonAsync<Client>($"api/clients/{id}"); }
            catch { return null; }
        }

        public async Task<Client?> CreateClientAsync(string name, string contact, string region)
        {
            AttachToken();
            var r = await _http.PostAsJsonAsync("api/clients", new { name, contactDetails = contact, region });
            return r.IsSuccessStatusCode ? await r.Content.ReadFromJsonAsync<Client>() : null;
        }

        public async Task<Client?> UpdateClientAsync(int id, string name, string contact, string region)
        {
            AttachToken();
            var r = await _http.PutAsJsonAsync($"api/clients/{id}", new { name, contactDetails = contact, region });
            return r.IsSuccessStatusCode ? await r.Content.ReadFromJsonAsync<Client>() : null;
        }

        public async Task<bool> DeleteClientAsync(int id)
        {
            AttachToken();
            return (await _http.DeleteAsync($"api/clients/{id}")).IsSuccessStatusCode;
        }

        // ── Contracts ────────────────────────────────────────────────────────
        public async Task<List<Contract>> GetContractsAsync(
            DateTime? from = null, DateTime? to = null, ContractStatus? status = null)
        {
            AttachToken();
            var url = "api/contracts";
            var qs  = new List<string>();
            if (from.HasValue)   qs.Add($"from={from.Value:yyyy-MM-dd}");
            if (to.HasValue)     qs.Add($"to={to.Value:yyyy-MM-dd}");
            if (status.HasValue) qs.Add($"status={status.Value}");
            if (qs.Any()) url += "?" + string.Join("&", qs);

            return await _http.GetFromJsonAsync<List<Contract>>(url) ?? new();
        }

        public async Task<Contract?> GetContractAsync(int id)
        {
            AttachToken();
            try { return await _http.GetFromJsonAsync<Contract>($"api/contracts/{id}"); }
            catch { return null; }
        }

        public async Task<(Contract? contract, string? error)> CreateContractAsync(
            ContractCreateViewModel vm)
        {
            AttachToken();
            var r = await _http.PostAsJsonAsync("api/contracts", new
            {
                clientId     = vm.ClientId,
                startDate    = vm.StartDate,
                endDate      = vm.EndDate,
                status       = vm.Status,
                serviceLevel = vm.ServiceLevel
            });

            if (!r.IsSuccessStatusCode)
            {
                var err = await r.Content.ReadAsStringAsync();
                return (null, err);
            }
            return (await r.Content.ReadFromJsonAsync<Contract>(), null);
        }

        public async Task<Contract?> PatchContractStatusAsync(int id, ContractStatus newStatus)
        {
            AttachToken();
            var r = await _http.PatchAsJsonAsync($"api/contracts/{id}/status", new { status = newStatus });
            return r.IsSuccessStatusCode ? await r.Content.ReadFromJsonAsync<Contract>() : null;
        }

        public async Task<bool> DeleteContractAsync(int id)
        {
            AttachToken();
            return (await _http.DeleteAsync($"api/contracts/{id}")).IsSuccessStatusCode;
        }

        // ── Service Requests ─────────────────────────────────────────────────
        public async Task<List<ServiceRequest>> GetServiceRequestsAsync()
        {
            AttachToken();
            return await _http.GetFromJsonAsync<List<ServiceRequest>>("api/servicerequests") ?? new();
        }

        public async Task<List<Contract>> GetActiveContractsAsync()
        {
            AttachToken();
            return await _http.GetFromJsonAsync<List<Contract>>("api/servicerequests/active-contracts") ?? new();
        }

        public async Task<ServiceRequest?> GetServiceRequestAsync(int id)
        {
            AttachToken();
            try { return await _http.GetFromJsonAsync<ServiceRequest>($"api/servicerequests/{id}"); }
            catch { return null; }
        }

        public async Task<(ServiceRequest? request, string? error)> CreateServiceRequestAsync(
            ServiceRequestCreateViewModel vm)
        {
            AttachToken();
            var r = await _http.PostAsJsonAsync("api/servicerequests", new
            {
                contractId  = vm.ContractId,
                description = vm.Description,
                costUsd     = vm.CostUsd
            });

            if (!r.IsSuccessStatusCode)
            {
                var err = await r.Content.ReadAsStringAsync();
                return (null, err);
            }
            return (await r.Content.ReadFromJsonAsync<ServiceRequest>(), null);
        }

        public async Task<bool> DeleteServiceRequestAsync(int id)
        {
            AttachToken();
            return (await _http.DeleteAsync($"api/servicerequests/{id}")).IsSuccessStatusCode;
        }
    }
}
