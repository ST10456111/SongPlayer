using GLMS.Frontend.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

// Session (stores JWT token between requests)
builder.Services.AddSession(opts =>
{
    opts.IdleTimeout     = TimeSpan.FromHours(8);
    opts.Cookie.HttpOnly = true;
    opts.Cookie.IsEssential = true;
});

builder.Services.AddHttpContextAccessor();

// Typed HTTP client pointing at the GLMS Backend API
var apiBase = builder.Configuration["ApiSettings:BaseUrl"]
              ?? "http://glms-backend-api:8080/";

builder.Services.AddHttpClient<IGlmsApiClient, GlmsApiClient>(client =>
    client.BaseAddress = new Uri(apiBase));

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseSession();
app.UseAuthorization();

app.MapControllerRoute(
    name:    "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
