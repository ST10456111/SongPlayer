using GLMS.Frontend.Models;
using GLMS.Frontend.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GLMS.Frontend.Controllers
{
    public class ContractsController : Controller
    {
        private readonly IGlmsApiClient _api;
        public ContractsController(IGlmsApiClient api) => _api = api;

        private bool IsLoggedIn => HttpContext.Session.GetString("JwtToken") != null;
        private IActionResult RequireLogin() => RedirectToAction("Login", "Account");

        public async Task<IActionResult> Index()
        {
            if (!IsLoggedIn) return RequireLogin();
            return View(await _api.GetContractsAsync());
        }

        public async Task<IActionResult> Search(ContractSearchViewModel vm)
        {
            if (!IsLoggedIn) return RequireLogin();
            vm.Results = await _api.GetContractsAsync(vm.StartDateFrom, vm.StartDateTo, vm.Status);
            return View(vm);
        }

        public async Task<IActionResult> Details(int id)
        {
            if (!IsLoggedIn) return RequireLogin();
            var contract = await _api.GetContractAsync(id);
            return contract == null ? NotFound() : View(contract);
        }

        public async Task<IActionResult> Create()
        {
            if (!IsLoggedIn) return RequireLogin();
            await PopulateClientsDropdown();
            return View(new ContractCreateViewModel());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ContractCreateViewModel vm)
        {
            if (!IsLoggedIn) return RequireLogin();
            if (!ModelState.IsValid)
            {
                await PopulateClientsDropdown();
                return View(vm);
            }

            var (contract, error) = await _api.CreateContractAsync(vm);
            if (error != null)
            {
                ModelState.AddModelError(string.Empty, error);
                await PopulateClientsDropdown();
                return View(vm);
            }

            TempData["Success"] = $"Contract #{contract!.Id} created.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateStatus(int id, ContractStatus status)
        {
            if (!IsLoggedIn) return RequireLogin();
            var result = await _api.PatchContractStatusAsync(id, status);
            TempData[result != null ? "Success" : "Error"] =
                result != null ? "Contract status updated." : "Failed to update status.";
            return RedirectToAction(nameof(Details), new { id });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            if (!IsLoggedIn) return RequireLogin();
            await _api.DeleteContractAsync(id);
            TempData["Success"] = "Contract deleted.";
            return RedirectToAction(nameof(Index));
        }

        private async Task PopulateClientsDropdown(int? selectedId = null)
        {
            var clients = await _api.GetClientsAsync();
            ViewBag.Clients = new SelectList(clients, "Id", "Name", selectedId);
        }
    }
}
