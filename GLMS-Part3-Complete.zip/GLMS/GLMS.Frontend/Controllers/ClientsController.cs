using GLMS.Frontend.Models;
using GLMS.Frontend.Services;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Frontend.Controllers
{
    public class ClientsController : Controller
    {
        private readonly IGlmsApiClient _api;
        public ClientsController(IGlmsApiClient api) => _api = api;

        private bool IsLoggedIn => HttpContext.Session.GetString("JwtToken") != null;
        private IActionResult RequireLogin() => RedirectToAction("Login", "Account");

        public async Task<IActionResult> Index()
        {
            if (!IsLoggedIn) return RequireLogin();
            return View(await _api.GetClientsAsync());
        }

        public async Task<IActionResult> Details(int id)
        {
            if (!IsLoggedIn) return RequireLogin();
            var client = await _api.GetClientAsync(id);
            return client == null ? NotFound() : View(client);
        }

        public IActionResult Create()
        {
            if (!IsLoggedIn) return RequireLogin();
            return View(new Client());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Client vm)
        {
            if (!IsLoggedIn) return RequireLogin();
            if (!ModelState.IsValid) return View(vm);

            var result = await _api.CreateClientAsync(vm.Name, vm.ContactDetails, vm.Region);
            if (result == null)
            {
                ModelState.AddModelError(string.Empty, "Failed to create client. Please try again.");
                return View(vm);
            }

            TempData["Success"] = $"Client '{result.Name}' created.";
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Edit(int id)
        {
            if (!IsLoggedIn) return RequireLogin();
            var client = await _api.GetClientAsync(id);
            return client == null ? NotFound() : View(client);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Client vm)
        {
            if (!IsLoggedIn) return RequireLogin();
            if (id != vm.Id) return BadRequest();
            if (!ModelState.IsValid) return View(vm);

            var result = await _api.UpdateClientAsync(id, vm.Name, vm.ContactDetails, vm.Region);
            if (result == null)
            {
                ModelState.AddModelError(string.Empty, "Update failed. Please try again.");
                return View(vm);
            }

            TempData["Success"] = "Client updated.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            if (!IsLoggedIn) return RequireLogin();
            await _api.DeleteClientAsync(id);
            TempData["Success"] = "Client deleted.";
            return RedirectToAction(nameof(Index));
        }
    }
}
