using GLMS.Frontend.Models;
using GLMS.Frontend.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace GLMS.Frontend.Controllers
{
    public class ServiceRequestsController : Controller
    {
        private readonly IGlmsApiClient _api;
        public ServiceRequestsController(IGlmsApiClient api) => _api = api;

        private bool IsLoggedIn => HttpContext.Session.GetString("JwtToken") != null;
        private IActionResult RequireLogin() => RedirectToAction("Login", "Account");

        public async Task<IActionResult> Index()
        {
            if (!IsLoggedIn) return RequireLogin();
            return View(await _api.GetServiceRequestsAsync());
        }

        public async Task<IActionResult> Details(int id)
        {
            if (!IsLoggedIn) return RequireLogin();
            var request = await _api.GetServiceRequestAsync(id);
            return request == null ? NotFound() : View(request);
        }

        public async Task<IActionResult> Create(int? contractId)
        {
            if (!IsLoggedIn) return RequireLogin();
            await PopulateContractsDropdown(contractId);
            return View(new ServiceRequestCreateViewModel { ContractId = contractId ?? 0 });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(ServiceRequestCreateViewModel vm)
        {
            if (!IsLoggedIn) return RequireLogin();
            if (!ModelState.IsValid)
            {
                await PopulateContractsDropdown(vm.ContractId);
                return View(vm);
            }

            var (request, error) = await _api.CreateServiceRequestAsync(vm);
            if (error != null)
            {
                ModelState.AddModelError(string.Empty, error);
                await PopulateContractsDropdown(vm.ContractId);
                return View(vm);
            }

            TempData["Success"] = $"Service Request #{request!.Id} created. Cost: R{request.CostZar:N2}";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            if (!IsLoggedIn) return RequireLogin();
            await _api.DeleteServiceRequestAsync(id);
            TempData["Success"] = "Service request deleted.";
            return RedirectToAction(nameof(Index));
        }

        private async Task PopulateContractsDropdown(int? selectedId = null)
        {
            var contracts = await _api.GetActiveContractsAsync();
            ViewBag.Contracts = new SelectList(
                contracts.Select(c => new
                {
                    c.Id,
                    Label = $"#{c.Id} — {c.Client?.Name ?? "Unknown"} ({c.ServiceLevel})"
                }),
                "Id", "Label", selectedId);
        }
    }
}
