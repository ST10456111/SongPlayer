using GLMS.Frontend.Models;
using GLMS.Frontend.Services;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Frontend.Controllers
{
    public class HomeController : Controller
    {
        private readonly IGlmsApiClient _api;
        public HomeController(IGlmsApiClient api) => _api = api;

        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("JwtToken") == null)
                return RedirectToAction("Login", "Account");

            var contracts = await _api.GetContractsAsync();
            var clients   = await _api.GetClientsAsync();
            var requests  = await _api.GetServiceRequestsAsync();

            ViewBag.ContractCount  = contracts.Count;
            ViewBag.ActiveCount    = contracts.Count(c => c.Status == ContractStatus.Active);
            ViewBag.ClientCount    = clients.Count;
            ViewBag.RequestCount   = requests.Count;
            ViewBag.UserEmail      = HttpContext.Session.GetString("UserEmail");
            ViewBag.RecentContracts = contracts.Take(5).ToList();

            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error() =>
            View(new ErrorViewModel { RequestId = System.Diagnostics.Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
