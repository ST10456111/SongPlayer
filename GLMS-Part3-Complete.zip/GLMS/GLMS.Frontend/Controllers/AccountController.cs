using GLMS.Frontend.Models;
using GLMS.Frontend.Services;
using Microsoft.AspNetCore.Mvc;

namespace GLMS.Frontend.Controllers
{
    public class AccountController : Controller
    {
        private readonly IGlmsApiClient _api;
        public AccountController(IGlmsApiClient api) => _api = api;

        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel vm, string? returnUrl = null)
        {
            if (!ModelState.IsValid) return View(vm);

            var result = await _api.LoginAsync(vm.Email, vm.Password);

            if (result == null)
            {
                ModelState.AddModelError(string.Empty, "Invalid email or password.");
                return View(vm);
            }

            HttpContext.Session.SetString("JwtToken",  result.Token);
            HttpContext.Session.SetString("UserEmail", result.Email);
            TempData["Success"] = $"Welcome back, {result.Email}!";

            return LocalRedirect(returnUrl ?? "/");
        }

        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Register(RegisterViewModel vm)
        {
            // Registration is handled through the admin panel; direct API call omitted
            // in favour of simplicity — admins create users via identity seeding.
            TempData["Error"] = "Self-registration is disabled. Please contact your administrator.";
            return View(vm);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            TempData["Success"] = "You have been logged out.";
            return RedirectToAction("Login");
        }
    }
}
