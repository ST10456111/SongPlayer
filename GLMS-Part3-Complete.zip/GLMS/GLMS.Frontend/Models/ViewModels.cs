using System.ComponentModel.DataAnnotations;

namespace GLMS.Frontend.Models
{
    // ── Enums (mirror backend) ────────────────────────────────────────────────
    public enum ContractStatus  { Draft, Active, Expired, OnHold }
    public enum ServiceLevel    { Standard, Premium, Enterprise }
    public enum RequestStatus   { Pending, InProgress, Completed, Cancelled }

    // ── API Response Models ──────────────────────────────────────────────────
    public class Client
    {
        public int    Id             { get; set; }
        public string Name           { get; set; } = string.Empty;
        public string ContactDetails { get; set; } = string.Empty;
        public string Region         { get; set; } = string.Empty;
        public List<Contract> Contracts { get; set; } = new();
    }

    public class Contract
    {
        public int           Id                 { get; set; }
        public int           ClientId           { get; set; }
        public Client?       Client             { get; set; }
        public DateTime      StartDate          { get; set; }
        public DateTime      EndDate            { get; set; }
        public ContractStatus  Status           { get; set; }
        public ServiceLevel    ServiceLevel     { get; set; }
        public string?       SignedAgreementPath { get; set; }
        public List<ServiceRequest> ServiceRequests { get; set; } = new();
    }

    public class ServiceRequest
    {
        public int           Id              { get; set; }
        public int           ContractId      { get; set; }
        public Contract?     Contract        { get; set; }
        public string        Description     { get; set; } = string.Empty;
        public decimal       CostUsd         { get; set; }
        public decimal       CostZar         { get; set; }
        public decimal       ExchangeRateUsed { get; set; }
        public RequestStatus Status          { get; set; }
        public DateTime      CreatedAt       { get; set; }
    }

    // ── View Models ──────────────────────────────────────────────────────────
    public class LoginViewModel
    {
        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required, DataType(DataType.Password)]
        public string Password { get; set; } = string.Empty;

        public bool RememberMe { get; set; }
    }

    public class RegisterViewModel
    {
        [Required, EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required, DataType(DataType.Password), MinLength(6)]
        public string Password { get; set; } = string.Empty;

        [Required, DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Passwords do not match.")]
        public string ConfirmPassword { get; set; } = string.Empty;
    }

    public class ContractCreateViewModel
    {
        [Required]
        public int ClientId { get; set; }

        [Required]
        public DateTime StartDate { get; set; } = DateTime.Today;

        [Required]
        public DateTime EndDate { get; set; } = DateTime.Today.AddYears(1);

        public ContractStatus Status       { get; set; } = ContractStatus.Draft;
        public ServiceLevel   ServiceLevel { get; set; } = ServiceLevel.Standard;
    }

    public class ContractSearchViewModel
    {
        public DateTime?      StartDateFrom { get; set; }
        public DateTime?      StartDateTo   { get; set; }
        public ContractStatus? Status       { get; set; }
        public List<Contract>  Results      { get; set; } = new();
    }

    public class ServiceRequestCreateViewModel
    {
        [Required]
        public int ContractId { get; set; }

        [Required, MaxLength(500)]
        public string Description { get; set; } = string.Empty;

        [Required, Range(0.01, double.MaxValue, ErrorMessage = "Cost must be greater than 0.")]
        public decimal CostUsd { get; set; }
    }

    public class AuthResponseDto
    {
        public string   Token  { get; set; } = string.Empty;
        public string   Email  { get; set; } = string.Empty;
        public DateTime Expiry { get; set; }
    }

    public class ErrorViewModel
    {
        public string? RequestId  { get; set; }
        public bool    ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
