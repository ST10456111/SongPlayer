using GLMS.Backend.Data;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace GLMS.Tests
{
    /// <summary>
    /// Boots the real GLMS.Backend application in-process for integration tests,
    /// replacing the SQL Server database with an isolated in-memory database so
    /// no external infrastructure is required.
    /// </summary>
    public class GlmsApiFactory : WebApplicationFactory<Program>
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.UseEnvironment("Testing");

            builder.ConfigureServices(services =>
            {
                // Remove the production SQL Server registration
                var descriptor = services.SingleOrDefault(
                    d => d.ServiceType == typeof(DbContextOptions<GlmsDbContext>));
                if (descriptor != null)
                    services.Remove(descriptor);

                // Replace with a unique in-memory DB per test class
                services.AddDbContext<GlmsDbContext>(opts =>
                    opts.UseInMemoryDatabase("GlmsTestDb_" + Guid.NewGuid()));
            });
        }
    }
}
