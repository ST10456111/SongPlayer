using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using FluentAssertions;
using GLMS.Backend.Data;
using GLMS.Backend.Models;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace GLMS.Tests
{
    // ════════════════════════════════════════════════════════════════════════
    // Contracts Integration Tests
    // ════════════════════════════════════════════════════════════════════════

    /// <summary>
    /// Integration tests for GET /api/contracts, POST /api/contracts,
    /// PATCH /api/contracts/{id}/status, DELETE /api/contracts/{id}.
    ///
    /// WHY integration tests?
    /// They call the running API over real HTTP, exercising routing, model binding,
    /// service logic, and JSON serialisation together — exactly what happens in
    /// production and in a CI/CD pipeline.
    /// </summary>
    public class ContractsIntegrationTests : IClassFixture<GlmsApiFactory>
    {
        private readonly HttpClient _client;
        private readonly GlmsApiFactory _factory;
        private static readonly JsonSerializerOptions Json =
            new() { PropertyNameCaseInsensitive = true };

        public ContractsIntegrationTests(GlmsApiFactory factory)
        {
            _factory = factory;
            _client  = factory.CreateClient();
        }

        // ── Helper: seed a client in the in-memory DB ─────────────────────
        private async Task<int> SeedClientAsync(string name = "Test Client")
        {
            using var scope = _factory.Services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<GlmsDbContext>();

            // Use a large random ID to avoid seed-data collisions
            var id = Random.Shared.Next(10_000, 99_999);
            db.Clients.Add(new Client
            {
                Id             = id,
                Name           = name,
                ContactDetails = "test@test.com",
                Region         = "ZA"
            });
            await db.SaveChangesAsync();
            return id;
        }

        private async Task<int> SeedContractAsync(int clientId)
        {
            using var scope = _factory.Services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<GlmsDbContext>();

            var id = Random.Shared.Next(10_000, 99_999);
            db.Contracts.Add(new Contract
            {
                Id           = id,
                ClientId     = clientId,
                StartDate    = DateTime.Today,
                EndDate      = DateTime.Today.AddYears(1),
                Status       = ContractStatus.Draft,
                ServiceLevel = ServiceLevel.Standard
            });
            await db.SaveChangesAsync();
            return id;
        }

        // ── Test 1: GET /api/contracts returns 200 and non-null JSON array ─
        [Fact]
        public async Task GetContracts_Returns200_AndNonNullList()
        {
            var response = await _client.GetAsync("/api/contracts");

            response.StatusCode.Should().Be(HttpStatusCode.OK,
                "GET /api/contracts must always return 200 OK");

            var content = await response.Content.ReadAsStringAsync();
            content.Should().NotBeNull("response body must not be null");

            var list = JsonSerializer.Deserialize<List<Contract>>(content, Json);
            list.Should().NotBeNull("JSON must deserialise to a list (even if empty)");
        }

        // ── Test 2: GET /api/contracts returns application/json ────────────
        [Fact]
        public async Task GetContracts_ReturnsJsonContentType()
        {
            var response = await _client.GetAsync("/api/contracts");
            response.Content.Headers.ContentType?.MediaType
                .Should().Be("application/json");
        }

        // ── Test 3: POST creates a contract and returns 201 ────────────────
        [Fact]
        public async Task PostContract_ValidData_Returns201AndContract()
        {
            var clientId = await SeedClientAsync("Post Client");

            var dto = new
            {
                clientId,
                startDate    = new DateTime(2025, 1, 1),
                endDate      = new DateTime(2025, 12, 31),
                status       = "Draft",
                serviceLevel = "Standard"
            };

            var response = await _client.PostAsJsonAsync("/api/contracts", dto);

            response.StatusCode.Should().Be(HttpStatusCode.Created,
                "a valid POST must return 201 Created");

            var created = await response.Content.ReadFromJsonAsync<Contract>(Json);
            created.Should().NotBeNull();
            created!.ClientId.Should().Be(clientId);
            created.Status.Should().Be(ContractStatus.Draft);
        }

        // ── Test 4: POST with non-existent client returns 400 ─────────────
        [Fact]
        public async Task PostContract_InvalidClientId_Returns400()
        {
            var dto = new
            {
                clientId     = 999_999,
                startDate    = DateTime.Today,
                endDate      = DateTime.Today.AddYears(1),
                status       = "Draft",
                serviceLevel = "Standard"
            };

            var response = await _client.PostAsJsonAsync("/api/contracts", dto);

            response.StatusCode.Should().Be(HttpStatusCode.BadRequest,
                "a non-existent clientId must cause 400 Bad Request");
        }

        // ── Test 5: GET /{invalid id} returns 404 ─────────────────────────
        [Fact]
        public async Task GetContract_InvalidId_Returns404()
        {
            var response = await _client.GetAsync("/api/contracts/999999");
            response.StatusCode.Should().Be(HttpStatusCode.NotFound);
        }

        // ── Test 6: PATCH /status updates the contract ────────────────────
        [Fact]
        public async Task PatchContractStatus_UpdatesSuccessfully()
        {
            var clientId   = await SeedClientAsync("Patch Client");
            var contractId = await SeedContractAsync(clientId);

            var response = await _client.PatchAsJsonAsync(
                $"/api/contracts/{contractId}/status",
                new { status = "Active" });

            response.StatusCode.Should().Be(HttpStatusCode.OK);

            var updated = await response.Content.ReadFromJsonAsync<Contract>(Json);
            updated!.Status.Should().Be(ContractStatus.Active,
                "PATCH /status must persist the new status");
        }

        // ── Test 7: DELETE returns 204; subsequent GET returns 404 ────────
        [Fact]
        public async Task DeleteContract_Returns204_AndIsGone()
        {
            var clientId   = await SeedClientAsync("Delete Client");
            var contractId = await SeedContractAsync(clientId);

            var deleteResponse = await _client.DeleteAsync($"/api/contracts/{contractId}");
            deleteResponse.StatusCode.Should().Be(HttpStatusCode.NoContent);

            var getResponse = await _client.GetAsync($"/api/contracts/{contractId}");
            getResponse.StatusCode.Should().Be(HttpStatusCode.NotFound,
                "a deleted contract must no longer be retrievable");
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // Clients Integration Tests
    // ════════════════════════════════════════════════════════════════════════

    public class ClientsIntegrationTests : IClassFixture<GlmsApiFactory>
    {
        private readonly HttpClient _client;
        private static readonly JsonSerializerOptions Json =
            new() { PropertyNameCaseInsensitive = true };

        public ClientsIntegrationTests(GlmsApiFactory factory)
            => _client = factory.CreateClient();

        // ── Test 8: GET /api/clients returns 200 and non-null list ────────
        [Fact]
        public async Task GetClients_Returns200_AndNonNullList()
        {
            var response = await _client.GetAsync("/api/clients");
            response.StatusCode.Should().Be(HttpStatusCode.OK);

            var list = JsonSerializer.Deserialize<List<Client>>(
                await response.Content.ReadAsStringAsync(), Json);
            list.Should().NotBeNull();
        }

        // ── Test 9: POST /api/clients creates a client with 201 ───────────
        [Fact]
        public async Task PostClient_ValidData_Returns201()
        {
            var dto = new
            {
                name           = "Integration Test Client " + Guid.NewGuid(),
                contactDetails = "it@test.com",
                region         = "ZA-Gauteng"
            };

            var response = await _client.PostAsJsonAsync("/api/clients", dto);

            response.StatusCode.Should().Be(HttpStatusCode.Created);
            var created = await response.Content.ReadFromJsonAsync<Client>(Json);
            created!.Name.Should().Contain("Integration Test Client");
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // Auth Integration Tests
    // ════════════════════════════════════════════════════════════════════════

    public class AuthIntegrationTests : IClassFixture<GlmsApiFactory>
    {
        private readonly HttpClient _client;

        public AuthIntegrationTests(GlmsApiFactory factory)
            => _client = factory.CreateClient();

        // ── Test 10: Bad credentials → 401 ────────────────────────────────
        [Fact]
        public async Task Login_InvalidCredentials_Returns401()
        {
            var dto = new { email = "nobody@nowhere.com", password = "WrongPass!" };
            var response = await _client.PostAsJsonAsync("/api/auth/login", dto);

            response.StatusCode.Should().Be(HttpStatusCode.Unauthorized,
                "invalid credentials must return 401 Unauthorized");
        }
    }
}
