# GLMS — Global Logistics Management System
### PROG7311 | Portfolio of Evidence — Part 3
**Student:** ST10456111

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│  Docker Compose — glms-network (internal bridge)                │
│                                                                 │
│  [Container 1]          [Container 2]          [Container 3]    │
│  sql-server-db    ←─── glms-backend-api ←─── glms-frontend-web │
│  SQL Server 2022        ASP.NET Core API        ASP.NET Core MVC│
│  Port: 1433             Port: 5000              Port: 5001       │
└─────────────────────────────────────────────────────────────────┘
```

- **GLMS.Backend** — Web API (REST). Sole component that touches the database. Exposes Swagger at `http://localhost:5000`.
- **GLMS.Frontend** — MVC frontend. NO database connection. Calls the API via `HttpClient` (session-JWT authenticated).
- **GLMS.Tests** — Integration tests using `WebApplicationFactory` + in-memory DB.

---

## Prerequisites

- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8)
- [Docker Desktop](https://www.docker.com/products/docker-desktop/)

---

## Running Locally (Development)

### 1. Start the API
```bash
cd GLMS.Backend
dotnet run
# API available at http://localhost:5000
# Swagger UI at   http://localhost:5000
```

### 2. Start the Frontend
```bash
cd GLMS.Frontend
dotnet run
# App available at http://localhost:5001
```

**Default login:** `admin@glms.com` / `Admin@123`

---

## Running in Docker (Production)

```bash
# From the GLMS/ root folder (where docker-compose.yml is):
docker compose up --build

# Frontend: http://localhost:5001
# API + Swagger: http://localhost:5000
# SQL Server: localhost:1433  (user: sa, password: GlmsP@ss123!)
```

---

## Running Integration Tests

```bash
cd GLMS.Tests
dotnet test --logger "console;verbosity=detailed"
```

Tests spin up the API in-process with an in-memory database — **no Docker required**.

---

## Design Patterns (from Part 2, retained in Backend)

| Pattern    | Class                      | Purpose                                     |
|------------|----------------------------|---------------------------------------------|
| Observer   | `ContractSubject` + `*Observer` | Notifies audit/email/dashboard on status change |
| Strategy   | `PricingStrategyFactory`   | Pricing tier: Standard / Premium / Enterprise |
| Decorator  | `ValidationDecorator`, `CurrencyDecorator`, `AuditLoggingDecorator` | SR processing pipeline |

---

## API Endpoints

| Method | Endpoint                        | Description                        |
|--------|---------------------------------|------------------------------------|
| POST   | /api/auth/login                 | Get JWT token                      |
| GET    | /api/contracts                  | List all (filter: from, to, status)|
| POST   | /api/contracts                  | Create contract                    |
| GET    | /api/contracts/{id}             | Get by ID                          |
| PUT    | /api/contracts/{id}             | Update contract                    |
| PATCH  | /api/contracts/{id}/status      | Update status (approve/decline)    |
| DELETE | /api/contracts/{id}             | Delete                             |
| GET    | /api/clients                    | List all clients                   |
| POST   | /api/clients                    | Create client                      |
| PUT    | /api/clients/{id}               | Update client                      |
| DELETE | /api/clients/{id}               | Delete client                      |
| GET    | /api/servicerequests            | List all requests                  |
| POST   | /api/servicerequests            | Create (runs decorator pipeline)   |
| DELETE | /api/servicerequests/{id}       | Delete                             |
